import * as React from 'react';
import { Button, Grid, Card, CardContent, Typography, CardHeader, CardMedia, Tooltip, Tab } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { styled } from '@mui/system';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import ImageIcon from '@mui/icons-material/Image';
import SimpleBackdrop from './loader';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

export default function ImgTab() {
    const [sourceImg, setSourceImg] = React.useState(null);
    const [destImg, setDestImg] = React.useState([]);

    const [highlightedSentence, setHighlightedSentence] = React.useState(null);

    const [openLoader, setOpenLoader] = React.useState(false);

    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };


    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });

    const handleTestFileChange = (event, value) => {
        const files = event.target.files;
        const allowedTypes = ['image/jpeg', 'image/png'];
        const validFiles = Array.from(files).filter(file => allowedTypes.includes(file.type) || file.name.toLowerCase().endsWith('.png') || file.name.toLowerCase().endsWith('.jpg'));

        if (validFiles.length > 0) {
            if (value === "source") {
                setSourceImg(validFiles[0]);
            } else if (value === "dest") {
                const totalSelectedImages = Object.keys(destImg).length + validFiles.length;

                if (totalSelectedImages <= 5) {
                    const remainingSlots = 5 - Object.keys(destImg).length;
                    const filesToAdd = validFiles.slice(0, remainingSlots);

                    setDestImg(prevState => ({
                        ...prevState,
                        ...filesToAdd.reduce((acc, file) => {
                            acc[file.name] = file;
                            return acc;
                        }, {})
                    }));

                } else {
                    handleClick("You can only select up to 5 images for comparison", "error");
                }
            }
        } else {
            handleClick("Allowed Image: PNG, JPG", "error");
        }
    };



    const handleFileChange = (event, value) => {
        const file = event.target.files[0];
        const fileType = file.type;
        if (file && (fileType === 'image/jpeg' || fileType === 'image/png')) {
            if (value === "source") {
                setSourceImg(file)
            } else if (value === "dest") {
                setDestImg(file)
            }
        } else {
            handleClick("Allowed Image: PNG, JPG", "error")
        }
    };


    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const docCompare = async () => {


        const formData = new FormData();
        formData.append('gd_file', sourceImg);
        Object.values(destImg).forEach(file => {
            formData.append('cp_file', file);
        });

        if (!sourceImg && !destImg) {
            handleClick("Please upload the Files", "error")
            return
        }

        setOpenLoader(true);
        try {
            let response = {}
            setHighlightedSentence()

            response = await AuthServices.imgCmp(formData);

            if (response) {

                setHighlightedSentence(response.output)
                setDestImg([])
                setSourceImg()

            }
        } catch (err) {

            const { data } = err || {}
            const { message } = data || {}
            handleClick(message, "error")


        } finally {
            setOpenLoader(false);
        }

    }


    const handleExport = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);

        // Trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Report.pdf';
        document.body.appendChild(a);
        a.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    const handleDragOver = (event) => {
        event.preventDefault();
    };

    const handleDropImage = (event, value) => {
        event.preventDefault();
        if (event.dataTransfer?.files?.length > 0) {
            const file = event.dataTransfer.files[0];

            if (file.type.startsWith('image/')) {
                if (value === "source") {
                    setSourceImg(file);
                }
            } else {
                console.log("Please drop an image file.");
            }
        } else {
            console.log("No files dropped or dataTransfer not supported.");
        }
    };
    const handleDropTestImage = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length + destImg.length <= 5) {
            setDestImg([...destImg, ...files]);
        } else {
            handleClick("You can only select up to 5 files for comparison", "error");
        }

    };

    const handleDragStart = (event, type) => {
        event.dataTransfer.setData("text/plain", type);
    };


    let cardStyle = { minWidth: "40%", minHeight: 150, margin: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', backgroundSize: 'cover', border: "2px dashed #70007d" }

    return (
        <>

            <SnackbarAlert
                severity={severity}
                message={message}
                open={open}
                handleClose={handleClose}
            />


            <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                <Card sx={cardStyle}
                    onDrop={(event) => handleDropImage(event, 'source')} onDragOver={handleDragOver}
                >
                    <CardContent sx={{ marginTop: 3 }}>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button' >
                            Source File
                            <VisuallyHiddenInput type="file" accept="image/*" onChange={(event) => handleFileChange(event, "source")} />
                        </Button>
                        <Tooltip title="Allowed File Types: PNG,JPG" sx={{ marginLeft: 1 }}>
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>

                        <Typography variant="subtitle1" color="textSecondary" sx={{ marginX: (sourceImg ? -3 : 5), marginY: 1 }}>
                            {sourceImg ? <strong><ImageIcon color='primary' /> {sourceImg.name}</strong> : 'Drag and Drop'}
                        </Typography>

                    </CardContent>
                </Card>
                <Card sx={cardStyle}
                    onDrop={(event) => handleDropTestImage(event, 'dest')} onDragOver={handleDragOver}
                >
                    <CardContent sx={{ marginTop: 3 }}>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Test file
                            <VisuallyHiddenInput type="file" accept="image/*" onChange={(event) => handleTestFileChange(event, "dest")} multiple />
                        </Button>
                        <Tooltip title="Allowed File Types: PNG, JPG" sx={{ marginLeft: 1 }}>
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>
                        <Typography variant="subtitle1" color="textSecondary" sx={{ marginX: (destImg ? -3 : 5), marginY: 1 }}>
                            {/* {destImg ? <strong><ImageIcon color='primary' /> {destImg.name}</strong> : 'Drag and Drop'} */}
                            {Object.keys(destImg).length > 0 && (
                            <Typography variant="primary" color="textSecondary">
                                <ImageIcon color='primary' /> 
                            </Typography>
                        )}
                            {Object.keys(destImg).map((fileIndex, index) => (
                                <Typography key={index} variant="subtitle1" color="textSecondary" style={{ display: 'inline-block' }}>
                                    {index > 0 ? ', ' : ''}
                                    {destImg[fileIndex].name}
                                </Typography>
                            ))}
                            {destImg.length === 0 && (
                                <Typography variant="subtitle1" color="textSecondary">
                                    Drag and Drop
                                </Typography>
                            )}

                        </Typography>
                    </CardContent>
                </Card>
            </Grid>

            <Grid container rowSpacing={2} alignItems="center" justifyContent="center" direction="row">

                <Grid item xs={1}>
                    <Button size="large" variant="contained" color='success' onClick={docCompare} sx={{ margin: 2 }}>Compare</Button>
                </Grid>
            </Grid>

            <SimpleBackdrop open={openLoader} />



            {highlightedSentence && (

                <div>
                    <TabContext value={value} >
                        <Grid container spacing={4} display="flex" alignItems="center" justifyContent="center" sx={{ margin: 2 }}>
                            <TabList onChange={handleChange} aria-label="lab API tabs example" variant="scrollable" indicatorColor="secondary"
                                scrollButtons className='exportTab'
                                allowScrollButtonsMobile>
                                {Object.keys(highlightedSentence).map((key, index) => (
                                    <Tab label={key} value={index} className='tabStyle' />
                                ))}

                            </TabList>
                            <Grid container spacing={1} alignItems="center" justifyContent="center" textAlign="center">
                                <Grid item xs={12} md={12} sm={12} >
                                    <h2>Comparison Result </h2>
                                </Grid>
                            </Grid>
                            {/* <Button variant="outlined" sx={{ margin: 2 }} color='secondary' onClick={handleExport(highlightedSentence?.report)} endIcon={<FileDownloadIcon />} >Export Report</Button> */}

                            <h3>Output File</h3>


                            {Object.keys(highlightedSentence).map((key, index) => (
                                <TabPanel value={index} key={index}>
                                    <Grid container spacing={1} alignItems="center" justifyContent="center">
                                        <Grid item xs={12} sx={{ marginLeft: 14 }}>
                                            <h4>Percentage of Image Similarity : <span>{highlightedSentence[key].percentage}%</span></h4>
                                            {/* <Button variant="outlined" onClick={handleExport(highlightedSentence?.html)} endIcon={<FileDownloadIcon />} >Export</Button> */}
                                        </Grid>
                                        <Grid item sx={{ margin: 2 }}>


                                            <Card sx={{ width: 400 }}>
                                                <CardHeader
                                                    title="Gold Image"
                                                />
                                                <CardMedia
                                                    component="img"
                                                    height="250"
                                                    image={`data:image/png;base64,${highlightedSentence[key].gd_file}`}
                                                    alt="Source"
                                                />

                                            </Card>
                                        </Grid>
                                        <Grid item sx={{ margin: 2 }}>
                                            <Card sx={{ width: 400 }}>
                                                <CardHeader
                                                    title="Test Image"
                                                />
                                                <CardMedia
                                                    component="img"
                                                    height="250"
                                                    image={`data:image/png;base64,${highlightedSentence[key].cp_file}`}
                                                    alt="Compare"
                                                />

                                            </Card>
                                        </Grid>
                                        {(highlightedSentence[key].percentage >= 90) ? <Grid item sx={{ margin: 2 }}>
                                            <Card sx={{ width: 400 }}>
                                                <CardHeader
                                                    title="Output Image"
                                                />
                                                <CardMedia
                                                    component="img"
                                                    height="250"
                                                    image={`data:image/png;base64,${highlightedSentence[key].highlighted}`}
                                                    alt="Compare"
                                                />

                                            </Card>
                                        </Grid> : ""}
                                    </Grid>

                                </TabPanel>
                            ))}

                        </Grid>
                    </TabContext>
                </div >


            )
            }

        </>
    )
}