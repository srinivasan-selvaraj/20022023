import * as React from 'react';
import Navbar from './navbar'
import { Box } from '@mui/material';
import LabTabs from './menu_tabs';

function Compare() {
    return (
        <>
            <Navbar />
            <Box maxWidth="xl" sx={{ marginTop: 5 }} >
                <LabTabs />
            </Box>
        </>
    )
}


export default Compare;