import * as React from 'react';
import { Button, Grid, CardContent, Typography, Paper, Tooltip, Tab } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { Box, styled } from '@mui/system';
import DescriptionIcon from '@mui/icons-material/Description';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SimpleBackdrop from './loader';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import FileViewer from "react-file-viewer";

export default function DocTab() {

    const [sourceFile, setSourceFile] = React.useState(null);
    const [compareFile, setCompareFile] = React.useState([]);

    const [highlightedSentence, setHighlightedSentence] = React.useState(null);
    const [openLoader, setOpenLoader] = React.useState(false);
    const defaultPage = 1

    const [currentPage, setCurrentPage] = React.useState(defaultPage);

    const [srcTotalPages, SetSrcTotalPages] = React.useState(1);

    const [value, setValue] = React.useState(0);
    const [totalDeleted, setTotalDeleted] = React.useState(null);
    const [totalWord, setTotalWord] = React.useState(null);
    const [totalInserted, setTotalInserted] = React.useState(null);
    const [totalCount, setTotalCount] = React.useState([]);

    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });

    const handleTestFileChange = (event) => {
        const files = event.target.files;
        const file = files[0];
        if (files.length > 5) {
            handleClick("Please select five files", "error");
            return;
        }
        if (file && isDocument(file)) {
            // Check if the maximum number of files has been reached

            if (files.length + compareFile.length <= 5) {
                setCompareFile([...compareFile, ...files]);
            } else {
                handleClick("You can only select up to 5 files for comparison", "error");
            }

        } else {
            handleClick("Accept only PDF file", "error");
        }
    };

    const handleSourceFileChange = (event, value) => {
        const file = event.target.files[0];

        if (file && isDocument(file)) {
            if (value === "source") {
                setSourceFile(file)

            } else if (value === "dest") {
                setCompareFile(file)

            }

        } else {
            handleClick("Accept only document file", "error")
        }
    };


    const isDocument = (file) => {
        return (


            file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        );
    };

    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const docCompare = async () => {

        if (!sourceFile && !compareFile) {
            handleClick("Please upload the Files", "error")
            return
        }

        const formData = new FormData();

        formData.append('gd_file', sourceFile);
        compareFile.forEach(file => {
            formData.append('cp_file', file);
        });

        setOpenLoader(true);

        try {
            let response = {}

            setHighlightedSentence()

            response = await AuthServices.docsCmp(formData);




            if (response) {

                setHighlightedSentence(response.output)
                setCompareFile([])
                setSourceFile()
                setCurrentPage(defaultPage)
                const output = Object.keys(response.output.result).map(key => response.output.result[key]);
                setTotalCount(output)
                const totalValue = output[value]
                setTotalDeleted(totalValue?.delete);
                setTotalWord(totalValue?.total_words);
                setTotalInserted(totalValue?.insert);

            }
        } catch (err) {

            const { data } = err || {}
            const { message } = data || {}
            handleClick(message, "error")


        } finally {
            setOpenLoader(false);
        }

    }

    function handlePreview(base64Data) {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        return url
    }

    const docView = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
        const url = URL.createObjectURL(blob);
        return url
    }



    const handleExport = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);

        // Trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Report.pdf';
        document.body.appendChild(a);
        a.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    const handleChange = (event, newValue) => {
        setValue(newValue);
        const totalValue = totalCount[newValue]
        setTotalDeleted(totalValue?.delete);
        setTotalWord(totalValue?.total_words);
        setTotalInserted(totalValue?.insert);

    };

    const handleDragOver = (event) => {
        event.preventDefault();
    };
    const handleDroptest = (event) => {
        event.preventDefault();
        const file = event.dataTransfer.files;
        if (file.length + compareFile.length <= 5) {
            setCompareFile([...compareFile, ...file]);
        } else {
            handleClick("You can only select up to 5 files for comparison", "error");
        }
    };
    const handleDrop = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            setSourceFile(file);
        }
    };

    const goToPreviousPage = () => {
        setCurrentPage((prevPage) => Math.max(prevPage - 1, 1)); // Ensure page number doesn't go below 1
    };

    const goToNextPage = () => {
        setCurrentPage((prevPage) => Math.min(prevPage + 1, srcTotalPages)); // Ensure page number doesn't exceed total pages
    };


    return (
        <>

            <SnackbarAlert
                severity={severity}
                message={message}
                open={open}
                handleClose={handleClose}
            />


            <Grid container rowSpacing={2} alignItems="center" justifyContent="flex-start" direction="row" sx={{ paddingX: 4 }}>

                <Grid item xs={12} md={6} >
                    <Box onDrop={handleDrop}
                        onDragOver={handleDragOver}
                        className='drag-box'>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Source File
                            <VisuallyHiddenInput type="file" accept=".docx" onChange={(event) => handleSourceFileChange(event, "source")} />
                        </Button>
                        <Tooltip title="Allowed File Types: DOCX">
                            <InfoOutlinedIcon color="disabled" fontSize="small" sx={{ marginX: "4px" }} />
                        </Tooltip>
                        {sourceFile ?
                            <Typography variant="subtitle1" color="textSecondary">
                                <DescriptionIcon color='primary' />  <strong>Gold Document:</strong> {sourceFile.name}
                            </Typography>

                            : (
                                <Typography variant="subtitle1" color="textSecondary">
                                    Drag and Drop
                                </Typography>
                            )}
                    </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                    <Box onDrop={handleDroptest}
                        onDragOver={handleDragOver}
                        className='drag-box'
                    >
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Test file
                            <VisuallyHiddenInput type="file" accept=".docx" onChange={(event) => handleTestFileChange(event, "dest")} multiple />
                        </Button>
                        <Tooltip title="Allowed File Types: DOCX">
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>

                        {Object.keys(compareFile).length > 0 && (
                            <Typography variant="subtitle1" color="textSecondary">
                                <DescriptionIcon color='primary' /> <strong>Test Documents:</strong>
                                {compareFile?.map(file => file.name).join(', ')}
                            </Typography>
                        )}

                        {compareFile.length === 0 && (
                            <Typography variant="subtitle1" color="textSecondary" >
                                Drag and Drop
                            </Typography>
                        )}
                    </Box>
                </Grid>

            </Grid>


            <Grid container rowSpacing={2} alignItems="center" justifyContent="center" direction="row">

                <Grid item xs={1}>
                    <Button size="large" variant="contained" color='success' onClick={docCompare} sx={{ margin: 2 }}>Compare</Button>
                </Grid>
            </Grid>

            <SimpleBackdrop open={openLoader} />

            {highlightedSentence && (

                <div>

                    <TabContext value={value} >
                        <Grid container spacing={4} display="flex" alignItems="center" justifyContent="center" textAlign="center" sx={{ marginY: 2 }}>
                            <TabList onChange={handleChange} aria-label="lab API tabs example" variant="scrollable" indicatorColor="secondary"
                                scrollButtons className='exportTab'
                                allowScrollButtonsMobile>
                                {Object.keys(highlightedSentence.result).map((key, index) => (
                                    <Tab label={key} value={index} className='tabStyle' />
                                ))}

                            </TabList>
                            <Grid container spacing={1} alignItems="center" justifyContent="center">
                                <Grid item xs={12} md={12} sm={12} >
                                    <h2>Comparison Result </h2>
                                </Grid>


                                <Grid item xs={12} md={4} sm={12} >
                                    <Paper elevation={1}>
                                        <CardContent >
                                            <Typography variant='body1' component='p'  > Total Words </Typography>
                                            <Typography variant='h4' component='h4'  >  {totalWord}</Typography>
                                        </CardContent>
                                    </Paper>
                                </Grid>
                                <Grid item xs={12} md={4} sm={6}>
                                    <Paper elevation={1}>
                                        <CardContent >
                                            <Typography variant='body1' component='p'  > Total Inserted Words </Typography>
                                            <Typography variant='h4' component='h4' color='green'  > {totalInserted}</Typography>
                                        </CardContent>
                                    </Paper>
                                </Grid>
                                <Grid item xs={12} md={4} sm={6}>
                                    <Paper elevation={1}>
                                        <CardContent >
                                            <Typography variant='body1' component='p'> Total Deleted Words </Typography>
                                            <Typography variant='h4' component='h4' color='red'> {totalDeleted}</Typography>
                                        </CardContent>

                                    </Paper>
                                </Grid>
                            </Grid>
                            {/* <Button variant="outlined" sx={{ margin: 2 }} color='secondary' onClick={handleExport(highlightedSentence?.report)} endIcon={<FileDownloadIcon />} >Export Report</Button> */}

                            <Grid container spacing={1} alignItems="center" justifyContent="center">
                                <Grid item xs={12} md={6} >

                                    <h3>Gold File</h3>
                                    <div style={{ border: '1px solid #bdbdbd', height: '200mm', width: '210mm', overflowY: 'auto' }}>
                                        <FileViewer
                                            fileType="pdf"
                                            filePath={handlePreview(highlightedSentence?.gold_base64)}
                                            onError={e => console.log('Error:', e)}

                                        />
                                    </div>
                                    {/* <PdfPreview pdf={handlePreview(highlightedSentence?.gold_base64)} currentPage={currentPage} SetTotalPages={SetSrcTotalPages} /> */}
                                </Grid>
                                <Grid item xs={12} md={6} >
                                    <h3>Output File</h3>
                                    {Object.keys(highlightedSentence.result).map((key, index) => (
                                        <TabPanel value={index} key={index}>
                                            <div style={{ border: '1px solid #bdbdbd', height: '200mm', width: '210mm', overflowY: 'auto' }}>
                                                <div dangerouslySetInnerHTML={{ __html: highlightedSentence.result[key].html[`Page_${currentPage}`] }} />
                                                {highlightedSentence.result[key][`Page_${currentPage}`]}
                                            </div>

                                        </TabPanel>
                                    ))}
                                </Grid>
                            </Grid>

                        </Grid>
                    </TabContext>

                </div >
            )}


        </>
    )
}