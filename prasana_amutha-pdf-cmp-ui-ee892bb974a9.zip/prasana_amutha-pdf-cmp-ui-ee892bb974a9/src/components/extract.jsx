import * as React from 'react';
import Navbar from './navbar'
import { Box } from '@mui/material';

function Extract() {
    return (
        <>
            <Navbar />
            <Box maxWidth="xl" sx={{ margin: 5 }} >
                
            </Box>
        </>
    )
}


export default Extract;