import * as React from 'react';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';


const SnackbarAlert = ({severity, message,handleClose,open}) => {
    
    return (
        <Snackbar open={open} autoHideDuration={1500} onClose={handleClose} anchorOrigin={ {horizontal: 'center', vertical: 'top'}} sx={{marginTop:4}} >
            <Alert
                onClose={handleClose}
                severity={severity}
                variant="filled"
                sx={{ width: '100%' }}
            >
                {message}
            </Alert>
        </Snackbar>
    )
}

export default SnackbarAlert