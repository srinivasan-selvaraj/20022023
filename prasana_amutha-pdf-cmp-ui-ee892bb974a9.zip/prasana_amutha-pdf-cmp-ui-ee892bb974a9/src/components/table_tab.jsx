import * as React from 'react';
import { Button, Grid, Typography, Tooltip } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { Box, styled } from '@mui/system';
import BackupTableIcon from '@mui/icons-material/BackupTable';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SimpleBackdrop from './loader';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';

export default function TableTab() {

    const [sourceFile, setSourceFile] = React.useState(null);
    const [compareFile, setCompareFile] = React.useState(null);
    const [highlightedtable, setHighlightedtable] = React.useState(null);
    const [columnstable, setColumnstable] = React.useState(null);
    const [dataTable, setDataTable] = React.useState(null);
    const [openLoader, setOpenLoader] = React.useState(false);


    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });


    const handleSourceFileChange = (event, value) => {
        const file = event.target.files[0];

        if (file && isDocument(file)) {
            if (value === "source") {
                setSourceFile(file)

            } else if (value === "dest") {
                setCompareFile(file)

            }

        } else {
            handleClick("Accept only PDF file", "error")
        }
    };


    const isDocument = (file) => {
        return (


            file.type === 'application/pdf'
        );
    };

    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const docCompare = async () => {

        if (!sourceFile && !compareFile) {
            handleClick("Please upload the Files", "error")
            return
        }

        const formData = new FormData();

        formData.append('gd_file', sourceFile);
        formData.append('cp_file', compareFile);

        setOpenLoader(true);

        try {
            let response = {}
            setHighlightedtable()
            setDataTable()
            setColumnstable()

            response = await AuthServices.tableCmp(formData);

            if (response) {

                const diffData = (response.output.diff);
                const diffValData = (response.output.diff_val);
                const diffValColumns = (response.output.diffval_columns);
                setHighlightedtable(diffValData)
                setDataTable(diffData)
                setColumnstable(diffValColumns)

            }
        } catch (err) {

            const { data } = err || {}
            const { message } = data || {}
            handleClick(message, "error")


        } finally {
            setOpenLoader(false);
        }

    }

    const handleExport = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);

        // Trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Report.pdf';
        document.body.appendChild(a);
        a.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    const handleDragOver = (event) => {
        event.preventDefault();
    };
    const handleDroptest = (event) => {
        event.preventDefault();
        const file = event.dataTransfer.files[0];
        setCompareFile(file);
    };
    const handleDrop = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            setSourceFile(file);
        }
    };


    return (
        <>

            <SnackbarAlert
                severity={severity}
                message={message}
                open={open}
                handleClose={handleClose}
            />


            <Grid container rowSpacing={2} alignItems="center" justifyContent="flex-start" direction="row" sx={{ paddingX: 4 }}>

                <Grid item xs={12} md={6} >
                    <Box onDrop={handleDrop}
                        onDragOver={handleDragOver}
                        className='drag-box'>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Source File
                            <VisuallyHiddenInput type="file" accept=".pdf" onChange={(event) => handleSourceFileChange(event, "source")} />
                        </Button>
                        <Tooltip title="Allowed File Types: PDF">
                            <InfoOutlinedIcon color="disabled" fontSize="small" sx={{ marginX: "4px" }} />
                        </Tooltip>
                        {sourceFile ?
                            <Typography variant="subtitle1" color="textSecondary">
                                <BackupTableIcon color='success' />  <strong>Source Document:</strong> {sourceFile.name}
                            </Typography>

                            : (
                                <Typography variant="subtitle1" color="textSecondary">
                                    Drag and Drop
                                </Typography>
                            )}
                    </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                    <Box onDrop={handleDroptest}
                        onDragOver={handleDragOver}
                        className='drag-box'
                    >
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Test file
                            <VisuallyHiddenInput type="file" accept=".pdf" onChange={(event) => handleSourceFileChange(event, "dest")} />
                        </Button>
                        <Tooltip title="Allowed File Types: PDF">
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>
                        {compareFile && (
                            <Typography variant="subtitle1" color="textSecondary">
                                <BackupTableIcon color='success' /> <strong>Compare Document:</strong> {compareFile.name}
                            </Typography>
                        )}
                        {!compareFile && (
                            <Typography variant="subtitle1" color="textSecondary">
                                Drag and Drop
                            </Typography>
                        )}
                    </Box>
                </Grid>

            </Grid>


            <Grid container rowSpacing={2} alignItems="center" justifyContent="center" direction="row">

                <Grid item xs={1}>
                    <Button size="large" variant="contained" color='success' onClick={docCompare} sx={{ margin: 2 }}>Compare</Button>
                </Grid>
            </Grid>

            <SimpleBackdrop open={openLoader} />

            {highlightedtable && (
                <Grid container rowSpacing={2} alignItems="center" justifyContent="center">
                    <Grid item sx={{ margin: 2 }}>
                        <h2>Comparison Result</h2>
                        <div>
                            <table border="1">
                                <thead>
                                    <tr>
                                        {columnstable.map((column, index) => (
                                            <th key={index.id}>{column.join(' / ')}</th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {highlightedtable.map((record, index) => (
                                        <tr key={index.id}>
                                            {columnstable.map((column, columnIndex) => (
                                                <td key={columnIndex.id} style={{ backgroundColor: dataTable[index][`('${column[0]}', '${column[1]}')`] ? 'yellow' : 'white' }}>
                                                    {record[`('${column[0]}', '${column[1]}')`] ? record[`('${column[0]}', '${column[1]}')`] : '-'}

                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                        </div>

                    </Grid>
                </Grid>
            )}


        </>
    )
}