import * as React from 'react';
import Navbar from './navbar'
import Compare from './compare';



function Home() {
    return (
            <Compare />

    )
}


export default Home;