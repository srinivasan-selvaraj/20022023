import React from 'react';
import { Backdrop, LinearProgress } from '@mui/material';
export default function SimpleLinearProgress({ open=true}) {
  return (
    <div>
     
       <div style={{ position: 'relative' }}>
      {open && (
        <div
          style={{
            color: '#fff',
            position: 'fixed',
            top: '0',
            left: 0,
            width: '100%',
            height: '100%',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 9999, 
          }}
        >
          <LinearProgress color="inherit" sx={{margin:'30%',width:'35%',}}/>
        </div>
      )}
      
    </div>
    </div>
  );
        }