import * as React from 'react';
import { Button, Grid, CardContent, Typography, Paper, Tooltip, Tab } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import { Box, styled } from '@mui/system';
import AuthServices from '../api/auth-services';
import SnackbarAlert from './snack_alert';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import SimpleBackdrop from './loader';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import DataObjectIcon from '@mui/icons-material/DataObject';
import ReactJson from 'react-json-view'
import TabContext from '@mui/lab/TabContext';
import TabList from '@mui/lab/TabList';
import TabPanel from '@mui/lab/TabPanel';

export default function JsonTab() {

    const [sourceFile, setSourceFile] = React.useState(null);
    const [compareFile, setCompareFile] = React.useState([]);

    const [highlightedSentence, setHighlightedSentence] = React.useState(null);
    const [openLoader, setOpenLoader] = React.useState(false);

    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };



    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });

    const handleTestFileChange = (event) => {
        const files = event.target.files;
        const file = files[0];
        if (files.length > 5) {
            handleClick("Please select five files", "error");
            return;
        }
        if (file && isDocument(file)) {
            // Check if the maximum number of files has been reached

            if (files.length + compareFile.length <= 5) {
                setCompareFile([...compareFile, ...files]);
            } else {
                handleClick("You can only select up to 5 files for comparison", "error");
            }

        } else {
            handleClick("Accept only PDF file", "error");
        }
    };

    const handleSourceFileChange = (event, value) => {
        const file = event.target.files[0];

        if (file && isDocument(file)) {
            setSourceFile(file)
        } else {
            handleClick("Accept only PDF file", "error")
        }
    };


    const isDocument = (file) => {
        return (

            file.type === 'application/json'
        );
    };

    const [severity, setSeverity] = React.useState(null);
    const [message, setMessage] = React.useState(null);

    const [open, setOpen] = React.useState(false);

    const handleClick = (msg, sev) => {
        setOpen(true);
        setSeverity(sev);
        setMessage(msg);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    const docCompare = async () => {

        if (!sourceFile || (sourceFile === undefined) || !compareFile) {
            handleClick("Please upload the Files", "error");
            return

        }
        const formData = new FormData();

        formData.append('gd_file', sourceFile);
        compareFile.forEach(file => {
            formData.append('cp_file', file);
        });

        setOpenLoader(true);
        try {
            let response = {}
            setHighlightedSentence()

            response = await AuthServices.jsonCmp(formData);

            if (response) {

                setHighlightedSentence(response.output)
                setCompareFile([])
                setSourceFile()


            }
        } catch (err) {

            const { data } = err || {}
            const { message } = data || {}
            handleClick(message, "error")


        } finally {
            setOpenLoader(false);
        }

    }


    const handleExport = (base64Data) => () => {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        // Create a URL for the Blob
        const url = URL.createObjectURL(blob);

        // Trigger download
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Report.pdf';
        document.body.appendChild(a);
        a.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    const handleDragOver = (event) => {
        event.preventDefault();
    };
    const handleDroptest = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length + compareFile.length <= 5) {
            setCompareFile([...compareFile, ...files]);
        } else {
            handleClick("You can only select up to 5 files for comparison", "error");
        }

    };
    const handleDrop = (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;
        if (files.length > 0) {
            const file = files[0];
            setSourceFile(file);
        }
    };


    return (
        <>

            <SnackbarAlert
                severity={severity}
                message={message}
                open={open}
                handleClose={handleClose}
            />


            <Grid container rowSpacing={2} alignItems="center" justifyContent="flex-start" direction="row" sx={{ paddingX: 4 }}>

                <Grid item xs={12} md={6} >
                    <Box onDrop={handleDrop}
                        onDragOver={handleDragOver}
                        className='drag-box'>
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Source File
                            <VisuallyHiddenInput type="file" accept=".json" onChange={(event) => handleSourceFileChange(event, "source")} />
                        </Button>
                        <Tooltip title="Allowed File Types: JSON">
                            <InfoOutlinedIcon color="disabled" fontSize="small" sx={{ marginX: "4px" }} />
                        </Tooltip>
                        {sourceFile ?
                            <Typography variant="subtitle1" color="textSecondary">
                                <DataObjectIcon color='warning' />  <strong>Gold Document:</strong> {sourceFile.name}
                            </Typography>

                            : (
                                <Typography variant="subtitle1" color="textSecondary">
                                    Drag and Drop
                                </Typography>
                            )}
                    </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                    <Box onDrop={handleDroptest}
                        onDragOver={handleDragOver}
                        className='drag-box'
                    >
                        <Button component="label" variant="contained" startIcon={<CloudUploadIcon />} className='upload-button'>
                            Test file
                            <VisuallyHiddenInput type="file" accept=".json" onChange={(event) => handleTestFileChange(event, "dest")} multiple />
                        </Button>
                        <Tooltip title="Allowed File Types: JSON">
                            <InfoOutlinedIcon color="disabled" fontSize="small" />
                        </Tooltip>
                        {Object.keys(compareFile).length > 0 && (
                            <Typography variant="subtitle1" color="textSecondary">
                                <DataObjectIcon color='warning' /> <strong>Test Documents:</strong>
                                {compareFile?.map(file => file.name).join(', ')}
                            </Typography>
                        )}
                    
                        {Object.keys(compareFile).length === 0 && (
                            <Typography variant="subtitle1" color="textSecondary">
                                Drag and Drop
                            </Typography>
                        )}
                    </Box>
                </Grid>

            </Grid>


            <Grid container rowSpacing={2} alignItems="center" justifyContent="center" direction="row">

                <Grid item xs={1}>
                    <Button size="large" variant="contained" color='success' onClick={docCompare} sx={{ margin: 2 }}>Compare</Button>
                </Grid>
            </Grid>

            <SimpleBackdrop open={openLoader} />

            {highlightedSentence?.gold_json && (

                <div>
                    <TabContext value={value} >
                        <Grid container spacing={4} display="flex" alignItems="center" justifyContent="center"  sx={{ margin: 2 }}>
                            <TabList onChange={handleChange} aria-label="lab API tabs example" variant="scrollable" indicatorColor="secondary"
                                scrollButtons className='exportTab'
                                allowScrollButtonsMobile>
                                {Object.keys(highlightedSentence.result).map((key, index) => (
                                    <Tab label={key} value={index} className='tabStyle' />
                                ))}

                            </TabList>
                            <Grid container spacing={1} alignItems="center" justifyContent="center" textAlign="center">
                                <Grid item xs={12} md={12} sm={12} >
                                    <h2>Comparison Result </h2>
                                </Grid>
                            </Grid>
                            {/* <Button variant="outlined" sx={{ margin: 2 }} color='secondary' onClick={handleExport(highlightedSentence?.report)} endIcon={<FileDownloadIcon />} >Export Report</Button> */}

                            <Grid container spacing={1} alignItems="center" justifyContent="center">
                                <Grid item xs={12} md={5} sx={{marginLeft:1}}>

                                    <h3>Gold File</h3>
                                    <ReactJson src={highlightedSentence?.gold_json} name={false} displayDataTypes={false} />
                                </Grid>
                                <Grid item xs={12} md={6} >
                                    <h3>Output File</h3>

                                    {Object.keys(highlightedSentence.result).map((key, index) => (
                                        <TabPanel value={index} key={index}>
                                            <div style={{ border: '1px solid #bdbdbd' }}>

                                                <div dangerouslySetInnerHTML={{ __html: highlightedSentence.result[key].json_result }} />
                                            </div>
                                        </TabPanel>
                                    ))}


                                </Grid>
                            </Grid>

                        </Grid>
                    </TabContext>
                </div>
            )}



        </>
    )
}