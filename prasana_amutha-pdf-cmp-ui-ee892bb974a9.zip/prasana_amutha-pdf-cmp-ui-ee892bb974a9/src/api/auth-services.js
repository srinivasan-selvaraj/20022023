import httpClient from './http-client';

const AuthServices = {
  // refreshToken: (data) => httpClient.get("REFRESH_TOKEN").then(response => response.data),

  // filterActiveAccounts: (city, state, country) => httpClient.get(`${"DASHBOARD"}/${city}/${state}/${country}`).then((response => response.data)),

  textCmp : (data) => httpClient.post("/text/compare",data).then((response => response.data)),

  docsCmp : (data) => httpClient.post("/docs/compare",data).then((response => response.data)),

  pdfCmp : (data) => httpClient.post("/pdf/compare",data).then((response => response.data)),

  jsonCmp : (data) => httpClient.post("/json/compare",data).then((response => response.data)),

  imgCmp : (data) => httpClient.post("/image/compare",data).then((response => response.data)),

  tableCmp : (data) => httpClient.post("/table/compare",data).then((response => response.data)),

  login : (data) => httpClient.post("/login/user",data).then((response => response.data)),

  dashboard : (data) => httpClient.get("/dashboard",data).then((response => response.data)),



};

export default AuthServices;
