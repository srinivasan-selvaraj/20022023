import asyncio
from math import atanh
import pandas
from tkinter import Tk
from tkinter.tix import Tk, Control, ComboBox
import asyncore
import asynchat
import socket


async def my_coroutine():
    await asyncio.sleep(1)
    print("Coroutine done")

async def main():
    task = asyncio.ensure_future(my_coroutine())
    await asyncio.gather(task)

def tkinter_example():
    root = Tk()

    # Create a Tix ComboBox widget
    combo = ComboBox(root)
    combo.grid(row=0, column=0)

    # Add items to the ComboBox
    combo.insert(0, "Option 1")
    combo.insert(1, "Option 2")
    combo.insert(2, "Option 3")

    # Start the main event loop
    root.mainloop()

class EchoHandler(asynchat.async_chat):
    """Handler class for the echo server."""
    
    def __init__(self, sock, addr):
        asynchat.async_chat.__init__(self, sock)
        self.set_terminator(b'\n')  # Terminator for end of message
        self.buffer = []

    def collect_incoming_data(self, data):
        """Collect incoming data from the client."""
        self.buffer.append(data)

    def found_terminator(self):
        """Handle the end of message terminator."""
        message = b''.join(self.buffer)
        self.buffer = []
        self.push(message + b'\n')  # Echo back the message to the client

class EchoServer(asyncore.dispatcher):
    """Echo server class."""

    def __init__(self, host, port):
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.bind((host, port))
        self.listen(5)  # Listen for incoming connections

    def handle_accept(self):
        """Handle new incoming connection."""
        sock, addr = self.accept()
        print(f'Incoming connection from {addr}')
        handler = EchoHandler(sock, addr)



if __name__ == "__main__":
    asyncio.run(main())
