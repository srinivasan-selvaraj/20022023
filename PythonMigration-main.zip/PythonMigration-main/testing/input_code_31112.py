# Assuming you have distutils installed
from distutils.core import setup

setup(
    name="mypackage",
    version="1.0.0",
)
