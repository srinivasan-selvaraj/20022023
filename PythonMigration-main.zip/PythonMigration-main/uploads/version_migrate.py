import json
import platform
from get_version import get_pkg_ver



# Load the JSON mapping
with open("deprecated_mapping.json", "r") as mapping_file:
    deprecated_mapping = json.load(mapping_file)

# Function to convert deprecated functions in code
def convert_deprecated_functions(old_migrate_version,code, mapping):
    replacements = mapping.get(old_migrate_version, [])
    if replacements:
        for replacement in replacements:
            deprecated_function = replacement["deprecated_function"]
            replacement_function = replacement["replacement"]
            code = code.replace(deprecated_function, replacement_function)
        return code
    return False


platform_version = platform.python_version()

print(f"current python version - {platform_version}")
# Read the input Python code
get_package_version = {}
with open("input_code.py", "r") as input_file:
    input_code = input_file.read()

    get_package_version = get_pkg_ver(input_code)

print(get_package_version,"version of the package")

old_version = input("Type the old version of PY : ")#3.6
migrate_version = input("Type the migrate version of PY : ")  #3.7
# Convert deprecated functions in the code
old_migrate_version = f"{old_version}-{migrate_version}"
updated_code = convert_deprecated_functions(old_migrate_version,input_code, deprecated_mapping)

if updated_code:
    # Save the updated code to an output file
    with open("output_code.py", "w") as output_file:
        output_file.write(updated_code)
else:
    print(f"No deprected functions are available for {old_migrate_version}")
