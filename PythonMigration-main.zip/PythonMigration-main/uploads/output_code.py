import asyncio
from math import atanh
import pandas

async def my_coroutine():
    await asyncio.sleep(1)
    print("Coroutine done")

async def main():
    task = asyncio.create_task(my_coroutine())
    await asyncio.gather(task)

if __name__ == "__main__":
    asyncio.run(main())
