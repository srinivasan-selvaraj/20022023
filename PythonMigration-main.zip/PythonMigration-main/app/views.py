from flask import render_template, request, send_file
from app.utils.get_version import get_pkg_ver
import json
import os
import platform
from zipfile import ZipFile, ZIP_DEFLATED
import shutil
from io import BytesIO
from app.utils.request_handler import ok_request, notok_request
from app.utils.webscrapy_main import scrapy_release_link,deprected_fun,read_deprected_link

platform_version = platform.python_version()


def convert_deprecated_functions(old_migrate_version, code, mapping, convert):
    replacements = mapping.get(old_migrate_version, [])
    get_deprect_migrate = {}
    if replacements:
        for replacement in replacements:
            deprecated_function = replacement["deprecated_function"]
            replacement_function = replacement["replacement"]
            if convert:
                code = code.replace(deprecated_function, replacement_function)
            else:
                if deprecated_function in code:
                    get_deprect_migrate[deprecated_function] = replacement_function
        return code if convert else get_deprect_migrate
    return False


def deprected_file():
    deprecated_mapping = {}
    with open("app/static/deprecated_mapping.json", "r") as mapping_file:
        deprecated_mapping = json.load(mapping_file)
    return deprecated_mapping


def home():
    versions = read_deprected_link()
    return render_template('index.html', platform_version=platform_version,versions=versions)


def version_file():
    uploaded_file = request.files['file']
    version = request.form['version']
    deprecated_mapping = deprected_file()
    codes = []

    def before_migrate(input_code, filename):
        file_contents = input_code.read()
        if type(file_contents) != type("str"):
            file_contents_str = file_contents.decode('utf-8')
        else:
            file_contents_str = file_contents
        get_package_version = get_pkg_ver(file_contents_str)
        old_migrate_version = version if version else f"{3.6}-{3.7}"
        updated_code = convert_deprecated_functions(
            old_migrate_version, file_contents_str, deprecated_mapping, False)
        migrate_code = {"filename": filename, "deprec_mgrt": updated_code,
                        "get_package_version": get_package_version, 'file_contents': file_contents_str}
        codes.append(migrate_code)

    if uploaded_file and uploaded_file.filename.split('.')[-1] in ['py', 'zip']:

        if uploaded_file.filename.split('.')[-1] == "py":
            before_migrate(uploaded_file, uploaded_file.filename)

        elif uploaded_file.filename.split('.')[-1] == "zip":
            uploads_folder = 'uploads'
            # if os.path.exists(uploads_folder):
            #     os.remove(uploads_folder)
            if not os.path.exists(uploads_folder):
                os.makedirs(uploads_folder)

            zip_path = os.path.join(uploads_folder, uploaded_file.filename)
            uploaded_file.save(zip_path)

            # Extract the zip file
            with ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(uploads_folder)

            extracted_files = os.listdir(uploads_folder)
            for file_name in extracted_files:
                if file_name.split('.')[-1] == "py":
                    file_path = os.path.join(uploads_folder, file_name)
                    with open(file_path) as file:
                        before_migrate(file, file_name)

        else:
            return notok_request({"message": "Invalid File"})
        return ok_request({"codes": codes})
    return notok_request({"message": "Invalid File"})


def migrate_file():
    uploads_folder = 'migrated'
   
    if not os.path.exists(uploads_folder):
        os.makedirs(uploads_folder)
    json_data = request.get_json()
    for key, value in json_data.items():
        input_code = value
        deprecated_mapping = deprected_file()
        old_migrate_version = f"{3.6}-{3.7}"
        updated_code = convert_deprecated_functions(
            old_migrate_version, input_code, deprecated_mapping, True)

        if updated_code:
            output = f"{uploads_folder}/{key}"
            with open(output, "w") as output_file:
                output_file.write(updated_code)
        else:
            print(
                f"No deprected functions are available for {old_migrate_version}")
    return ok_request({"message":"Migrated successfully"})


def download():
    project_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    output_path = f"{project_path}\migrated"
    memory_file = BytesIO()
    abs_src = os.path.abspath(output_path)
    with ZipFile(memory_file, 'w', ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(output_path):
            try:
                for file in files:
                    absname = os.path.abspath(os.path.join(root, file))
                    arcname = absname[len(abs_src) + 1:]
                    zipf.write(absname, arcname)
            except Exception as e:
                print(e)
    memory_file.seek(0)
    if os.path.exists(output_path):
        shutil.rmtree(output_path)
    return send_file(memory_file, as_attachment=True, download_name='output.zip')


def generate_deprec():
    status = scrapy_release_link()
    if status:
        return ok_request({"message":"Generated Deprected Json successfully"})
    return notok_request({"message": "Something Wrong!"})


def extract_deprec():
    status = deprected_fun("3.12.2")
    if status:
        print(status)
        return ok_request({"message":"Extracted Deprected successfully","removed_deprected":status})
    return notok_request({"message": "Something Wrong!"})