from app import app
from app.views import home,migrate_file,version_file,download,generate_deprec,extract_deprec


app.add_url_rule("/", methods=["GET"], view_func=home)

app.add_url_rule("/download", methods=["GET"], view_func=download)

app.add_url_rule("/files_version", methods=["POST"], view_func=version_file)

app.add_url_rule("/file_migrate", methods=["POST"], view_func=migrate_file)

app.add_url_rule("/generate_deprec", methods=["GET"], view_func=generate_deprec)

app.add_url_rule("/extract_deprec", methods=["GET"], view_func=extract_deprec)