import requests
from bs4 import BeautifulSoup
import json
import os
import re

link_output_file = "app/static/output.json"


def version_key(version):
    # Split the version string into major, minor, and patch numbers
    major, minor, patch = map(int, re.match(r'(\d+)\.(\d+)\.(\d+)', version).groups())
    return major, minor, patch

def read_deprected_link():
    versions = []
    if os.path.exists(link_output_file):
        with open(link_output_file, 'r') as json_file:
            data_from_file = json.load(json_file)
        versions = [key for key in data_from_file.keys() if data_from_file[key].get('deprected') ]
    return sorted(versions,reverse=True,key=version_key)

def scrapy_release_link():
    # Send an HTTP request to the URL
    url = 'https://www.python.org/downloads/'

    response = requests.get(url)
    status = False
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the HTML content of the page
        soup = BeautifulSoup(response.text, 'html.parser')

        # Find all <span> tags within the specified class
        release_widgets = soup.find_all('span', class_='release-number')

        # Initialize a list to store dictionaries
        result_dict = {}
        print("Loading..", end="", flush=True)
        # Iterate through each <span> tag
        for release_widget in release_widgets:
            # Find the <a> tag within the <span> for each element
            a_tag = release_widget.find('a')

            # Check if the <a> tag is found
            if a_tag:
                # Extract href and name values
                
                href_value = a_tag['href']
                name_value = a_tag.get_text(strip=True)
                name_value = name_value.replace("Python ", "")
                # Create a dictionary for each <span> tag
                
                try:
                    deprected_link = get_deprected_link(name_value)
                except Exception as e:
                    print(e)
                    deprected_link = None
                result_dict[name_value] = {"release":f"https://www.python.org{href_value}","deprected":deprected_link}
            print(".", end="", flush=True)
        print()
        sorted_result_dict = dict(sorted(result_dict.items(), reverse=True))
        with open(link_output_file, 'w') as json_file:
            json.dump(sorted_result_dict, json_file, indent=4)
        status = True
    return status



def get_deprected_link(version):
    # Print or use the loaded dictionary

    url = f"https://docs.python.org/release/{version}/whatsnew/"

    response = requests.get(url)
    status = ""
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        specific_release = soup.find_all('a', class_='reference internal')
        for items in specific_release:
            if href_value := items.get('href'):
                name_value = items.get_text(strip=True)
                if name_value == "Deprecated":
                    status = f"{url}{href_value}"
                    break
    return status


def deprected_fun(version):
    status = []
    # Read the JSON file
    with open(link_output_file, 'r') as json_file:
        data_from_file = json.load(json_file)
    # Example: Retrieve the value associated with the key "3.11.1"
    version_dict = data_from_file.get(version)
    url = version_dict.get('deprected') if version_dict else None
    if url:
        response = requests.get(url)
        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            deprected_widgets = soup.find('section', id='deprecated')
            list_deprected = []
            if deprected_widgets:
                list_deprected = deprected_widgets.find_all('p')
            removed_widgets = soup.find('section', id='removed')
            list_removed = []
            if removed_widgets:
                list_removed = removed_widgets.find_all('p')
            status = {"deprected":list_deprected,"removed":list_removed}
    return status
