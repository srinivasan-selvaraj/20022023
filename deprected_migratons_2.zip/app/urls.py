from app import app
from app.views import home,migrate_file,version_file


app.add_url_rule("/", methods=["GET"], view_func=home)

app.add_url_rule("/files_version", methods=["POST"], view_func=version_file)

app.add_url_rule("/file_migrate", methods=["POST"], view_func=migrate_file)