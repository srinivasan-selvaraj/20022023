from flask import render_template,request,send_file
from get_version import get_pkg_ver
import json,os
import platform
import zipfile
import shutil
from app.utils.request_handler import ok_request,notok_request

platform_version = platform.python_version()

def convert_deprecated_functions(old_migrate_version,code, mapping,convert):
    replacements = mapping.get(old_migrate_version, [])
    get_deprect_migrate = {}
    if replacements:
        for replacement in replacements:
            deprecated_function = replacement["deprecated_function"]
            replacement_function = replacement["replacement"]
            if convert:
                code = code.replace(deprecated_function, replacement_function)
            else:
                if deprecated_function in code:
                    get_deprect_migrate[deprecated_function] = replacement_function
        return code if convert else get_deprect_migrate
    return False

def deprected_file():
    deprecated_mapping = {}
    with open("deprecated_mapping.json", "r") as mapping_file:
        deprecated_mapping = json.load(mapping_file)
    return deprecated_mapping

def home():
    return render_template('index.html',platform_version=platform_version)

def version_file():
    uploaded_file = request.files['file']
    version = request.form['version']
    deprecated_mapping = deprected_file()
    codes = []

    def before_migrate(input_code,filename):
        file_contents = input_code.read()
        if type(file_contents) != type("str"):
            file_contents_str = file_contents.decode('utf-8')
        else:
            file_contents_str = file_contents
        get_package_version = get_pkg_ver(file_contents_str)
        old_migrate_version = version if version else f"{3.6}-{3.7}" 
        updated_code = convert_deprecated_functions(old_migrate_version,file_contents_str, deprecated_mapping,False)
        migrate_code = {"filename":filename,"deprec_mgrt":updated_code,"get_package_version":get_package_version,'file_contents':file_contents_str}
        codes.append(migrate_code)

    if uploaded_file and uploaded_file.filename.split('.')[-1] in ['py','zip']:

        if uploaded_file.filename.split('.')[-1] == "py":
            before_migrate(uploaded_file,uploaded_file.filename)

        elif uploaded_file.filename.split('.')[-1] == "zip":
            uploads_folder = 'uploads'
            # if os.path.exists(uploads_folder):
            #     os.remove(uploads_folder)
            if not os.path.exists(uploads_folder):
                os.makedirs(uploads_folder)
            
            zip_path = os.path.join(uploads_folder, uploaded_file.filename)
            uploaded_file.save(zip_path)

            # Extract the zip file
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(uploads_folder)

            extracted_files = os.listdir(uploads_folder)
            for file_name in extracted_files:
                if file_name.split('.')[-1] == "py":
                    file_path = os.path.join(uploads_folder, file_name)
                    with open(file_path) as file:
                        before_migrate(file,file_name)
            
        else:
            return notok_request({"message":"Invalid File"})
        return ok_request({"codes":codes})
    return notok_request({"message":"Invalid File"})

def migrate_file():
    uploads_folder = 'migrated'
    # if os.path.exists(uploads_folder):
    #     os.remove(uploads_folder)
    if not os.path.exists(uploads_folder):
        os.makedirs(uploads_folder)
    json_data = request.get_json()
    for key,value in json_data.items():
        input_code = value
        deprecated_mapping = deprected_file()
        old_migrate_version = f"{3.6}-{3.7}"
        updated_code = convert_deprecated_functions(old_migrate_version,input_code, deprecated_mapping,True)

        if updated_code:
            output = f"{uploads_folder}/{key}"
            with open(output, "w") as output_file:
                output_file.write(updated_code)
        else:
            print(f"No deprected functions are available for {old_migrate_version}")
    

    shutil.make_archive(uploads_folder, 'zip', uploads_folder)
    project_path = os.path.dirname(os.path.abspath(__file__))
    uploads_path = os.path.join(project_path, f"{uploads_folder}.zip")
    return send_file(uploads_path, as_attachment=True, download_name='output.zip')

  