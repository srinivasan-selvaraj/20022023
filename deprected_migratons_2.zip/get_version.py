import ast
import pkg_resources

def get_pkg_ver(input_code):

    # Parse the code into an abstract syntax tree (AST)
    ast_tree = ast.parse(input_code)

    # Initialize a dictionary to store imported modules and their versions
    imported_modules = {}
    def module_version(module_name):
        try:
            module_version = pkg_resources.get_distribution(module_name).version
            imported_modules[module_name] = module_version
        except pkg_resources.DistributionNotFound:
            imported_modules[module_name] = None

    # Traverse the AST and extract imported modules
    for node in ast.walk(ast_tree):
        if isinstance(node, ast.Import):
            for name in node.names:
                module_name = name.name
                module_version(module_name)
                
        elif isinstance(node, ast.ImportFrom):
            for name in node.names:
                module_name = f"{node.module}.{name.name}"
                module_version(module_name)
                

    return imported_modules


