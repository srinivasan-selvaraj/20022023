from app import app
from app.views import home


app.add_url_rule("/", methods=["GET"], view_func=home)